﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Empresa.Models   //Isto é uma Biblioteca
{
    //Sealed mostra que é o "final", pois não deixa nenhuma outra classe herdar de uma classe com sealed, apenas instanciar.
    public sealed class Cliente:EntidadeBase
    {

    }
}
