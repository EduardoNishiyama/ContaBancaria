﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Empresa.Models
{
    //Classes do tipo Models são classes possui a estrutura de dados. (Modelo de dados)
    //Abstract é uma forma de marcar a Base, pois ele não permite instanciar apenas herdar.
    public abstract class EntidadeBase
    {
        //Serve apenas para armazenar informações.
        public int Id { get; set; }
        public string Nome { get; set; }
        public string Email { get; set; }
        public string Telefone { get; set; }
    }
}
