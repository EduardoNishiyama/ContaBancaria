﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Empresa.Db
{
    //Helper - Para acesso a dados.
    public static class Db
    {
        public static string Conexao
        {
            get
            {
                //Retorna a string de conexão com o bd Local. Basta verificar as informações DataSource, ID e Password.
                return @"Data Source=DESKTOP-L58LBSU\SQLEXPRESS;Initial Catalog=Empresa;User ID=sa;Password=*******;";
            }
        }
    }
}
