﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient; // Namespace para uso do SQL Server
using Empresa.Models; // Namespace criado para uso do desenvolvimento.

namespace Empresa.Db
{
    public class ClienteDb
    {
        public void Incluir(Cliente cliente) //Método Icluir recebe cliente da classe Cliente (Criada em Models)
        {
            string sql = "INSERT INTO Cliente (Id, Nome, Email, Telefone) Values(@Id, @Nome, @Email, @Telefone)"; // Variavel que contem a string para ser executada.
            var cn = new SqlConnection(Db.Conexao); //Instanciando uma conexão, recebendo como parametro a classe Db que criei com o método de conectar com a string de conexão.

            var cmd = new SqlCommand(sql, cn); //Instanciando o comando que deve ser executado com parametro do Comando sql e a conexão.
            cmd.Parameters.AddWithValue("@Id", cliente.Id); //Parametro com referencia ao Id
            cmd.Parameters.AddWithValue("@Nome", cliente.Nome); //Parametro com Referencia ao Nome
            cmd.Parameters.AddWithValue("@Email", cliente.Email); //Parametro com Referencia ao Email
            cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone); //Parametro com Referencia ao Telefone
            cn.Open(); //Abrindo a Conexão com o Banco de Dados
            cmd.ExecuteNonQuery(); //Executando os comandos sql com as Referencias de cmd
            cn.Close(); //Fechando a Conexão com o Banco de Dados
        }

        public void Alterar(Cliente cliente) //Método Icluir recebe cliente da classe Cliente (Criada em Models)
        {
            string sql = @"UPDATE Cliente 
                            SET Nome=@Nome, Email=@Email, Telefone=@Telefone WHERE Id=@Id"; //String com comando Sql desejado. 
            var cn = new SqlConnection(Db.Conexao); //Instanciando uma conexão, recebendo como parametro a classe Db que criei com o método de conectar com a string de conexão.

            var cmd = new SqlCommand(sql, cn); //Instanciando o comando que deve ser executado com parametro do Comando sql e a conexão.
            cmd.Parameters.AddWithValue("@Id", cliente.Id); //Parametro com referencia ao Id
            cmd.Parameters.AddWithValue("@Nome", cliente.Nome); //Parametro com Referencia ao Nome
            cmd.Parameters.AddWithValue("@Email", cliente.Email); //Parametro com Referencia ao Email
            cmd.Parameters.AddWithValue("@Telefone", cliente.Telefone); //Parametro com Referencia ao Telefone
            cn.Open(); //Abrindo a Conexão com o Banco de Dados
            cmd.ExecuteNonQuery(); //Executando os comandos sql com as Referencias de cmd
            cn.Close(); //Fechando a Conexão com o Banco de Dados
        }

        public void Excliur(int Id) //Método Icluir recebe cliente da classe Cliente (Criada em Models)
        {
            string sql = @"DELETE Cliente WHERE Id=@Id"; //String com comando Sql desejado. 
            var cn = new SqlConnection(Db.Conexao); //Instanciando uma conexão, recebendo como parametro a classe Db que criei com o método de conectar com a string de conexão.

            var cmd = new SqlCommand(sql, cn); //Instanciando o comando que deve ser executado com parametro do Comando sql e a conexão.
            cmd.Parameters.AddWithValue("@Id", Id); //Parametro com referencia ao Id
            cn.Open(); //Abrindo a Conexão com o Banco de Dados
            cmd.ExecuteNonQuery(); //Executando os comandos sql com as Referencias de cmd
            cn.Close(); //Fechando a Conexão com o Banco de Dados
        }

        public List<Cliente> Listar()
        {
            string sql = "SELECT Id,Nome,Email,Telefone FROM Cliente";
            var cn = new SqlConnection(Db.Conexao); //Instanciando uma conexão, recebendo como parametro a classe Db que criei com o método de conectar com a string de conexão.
            var cmd = new SqlCommand(sql, cn); //Instanciando o comando que deve ser executado com parametro do Comando sql e a conexão.

            List<Cliente> lista = new List<Cliente>(); //Retornar uma lista de clientes.

            cn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while(reader.Read())
            {
                var cliente = new Cliente();
                cliente.Id = Convert.ToInt32(reader["Id"]);
                cliente.Nome = reader["Nome"].ToString();
                cliente.Email = reader["Email"].ToString();
                cliente.Telefone = reader["Telefone"].ToString();

                lista.Add(cliente);
            }
            reader.Close();
            cn.Close();
            return lista;
        }
    }
}
